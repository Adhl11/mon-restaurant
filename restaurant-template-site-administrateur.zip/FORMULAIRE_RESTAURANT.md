# 📋 FORMULAIRE DE CONFIGURATION DU RESTAURANT

*Remplissez les sections ci-dessous. Une fois terminé, demandez-moi dans le chat de mettre à jour le site.*

---

## 1. INFORMATIONS GÉNÉRALES

| Champ | Votre Valeur |
| :--- | :--- |
| **Nom du Restaurant** | |
| **Mot en couleur (Highlight)** | |
| **Mot en italique (Accent)** | |
| **Slogan (Tagline)** | |
| **Description longue (Accueil)** | |
| **Description courte (Pied de page)** | |
| **Adresse complète** | |
| **Téléphone** | |
| **Email** | |
| **Horaires** | |
| **Lien Instagram (ou #)** | |
| **Lien Facebook (ou #)** | |

---

## 2. LE MENU

*Ajoutez vos plats un par un en suivant ce format :*
*Format : [Nom du Plat] | [Description/Ingrédients] | [Prix] | [Catégorie]*

*Catégories : `antipasti`, `salade`, `pizza`, `pasta`, `risotto`, `carne`, `pesce`, `dolci`, `specialite`*

- [Exemple : Pizza Margherita] | [Tomate, mozzarella, basilic frais] | [12€] | [pizza]
- 
- 
- 
- 
- 
- 
- 
- 
- 
- 
- 
- 
- 
- 
