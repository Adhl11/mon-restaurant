/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_STANDALONE_RESTAURANT_SLUG: string;
  // add other env variables here...
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
