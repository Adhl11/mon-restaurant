import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { useConfig } from "@/ConfigContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Plus, Send } from "lucide-react";
import { cn } from "@/lib/utils";
import { Restaurant, MenuItem } from "@/types";
import QuickOrderModal from "./QuickOrderModal";

interface MenuProps {
  restaurant?: Restaurant;
  menu?: MenuItem[];
}

export default function Menu({ restaurant: propRestaurant, menu: propMenu }: MenuProps) {
  const config = useConfig();
  const restaurant = propRestaurant || config?.restaurant;
  const menu = propMenu || config?.menu || [];
  const isLoading = propRestaurant ? false : config?.isLoading;
  
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);

  const handleOrderClick = (item: MenuItem) => {
    setSelectedItem(item);
    setIsOrderModalOpen(true);
  };
  
  if (isLoading && !propRestaurant) return null;
  const categories = [
    { id: 'all', label: 'Tout' },
    { id: 'antipasti', label: 'Entrées' },
    { id: 'salade', label: 'Salades' },
    { id: 'pizza', label: 'Pizzas' },
    { id: 'pasta', label: 'Pâtes' },
    { id: 'risotto', label: 'Risottos' },
    { id: 'carne', label: 'Viandes' },
    { id: 'pesce', label: 'Poissons' },
    { id: 'dolci', label: 'Desserts' },
    { id: 'specialite', label: 'Spécialités' },
  ];

  // Filter categories that actually have items
  const activeCategories = categories.filter(cat => 
    cat.id === 'all' || menu.some(item => item.category === cat.id)
  );

  const layoutStyle = restaurant?.config.layoutStyle || 'modern';

  return (
    <section id="menu" className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-heading font-bold mb-4">Notre Carte</h2>
          <div className="w-24 h-1 bg-primary mx-auto mb-6" />
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Découvrez nos créations culinaires préparées avec passion et des produits de qualité.
          </p>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <div className="flex justify-center mb-12">
            <TabsList className="bg-secondary/50 p-1 rounded-full border border-border flex-wrap h-auto">
              {activeCategories.map((cat) => (
                <TabsTrigger 
                  key={cat.id} 
                  value={cat.id}
                  className="rounded-full px-6 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all"
                >
                  {cat.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          <AnimatePresence mode="wait">
            {activeCategories.map((cat) => (
              <TabsContent key={cat.id} value={cat.id} className="mt-0">
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.4 }}
                  className={cn(
                    "grid gap-8",
                    layoutStyle === 'classic' ? "grid-cols-1 max-w-3xl mx-auto" : "grid-cols-1 md:grid-cols-2 lg:grid-cols-3"
                  )}
                >
                  {menu.filter(item => cat.id === 'all' || item.category === cat.id).map((item) => (
                    <motion.div
                      key={item.id}
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3 }}
                    >
                      {layoutStyle === 'classic' ? (
                        <div className="flex justify-between items-center border-b border-dashed border-slate-200 pb-4 group">
                          <div className="flex-1 pr-4">
                            <h3 className="text-xl font-heading font-bold group-hover:text-primary transition-colors">
                              {item.name}
                            </h3>
                            <p className="text-muted-foreground text-sm italic">{item.description}</p>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-xl font-black text-primary">
                              {item.price.toFixed(2)} €
                            </div>
                            <Button 
                              size="icon" 
                              variant="ghost" 
                              className="rounded-full hover:bg-primary hover:text-white transition-colors"
                              onClick={() => handleOrderClick(item)}
                            >
                              <Plus className="w-5 h-5" />
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <Card className={cn(
                          "overflow-hidden border-none shadow-lg hover:shadow-xl transition-shadow group bg-card rounded-2xl",
                          layoutStyle === 'elegant' ? "shadow-none border border-slate-100" : ""
                        )}>
                          <div className={cn(
                            "relative overflow-hidden",
                            layoutStyle === 'elegant' ? "h-48" : "h-64"
                          )}>
                            <img 
                              src={item.image} 
                              alt={item.name} 
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute top-4 right-4">
                              <Badge className="bg-white/90 text-primary font-bold text-lg px-3 py-1 backdrop-blur-sm">
                                {item.price} €
                              </Badge>
                            </div>
                          </div>
                          <CardContent className="p-6">
                            <div className="flex justify-between items-start mb-2">
                              <h3 className="text-2xl font-heading font-bold group-hover:text-primary transition-colors">
                                {item.name}
                              </h3>
                            </div>
                            <p className="text-muted-foreground text-sm leading-relaxed italic mb-4">
                              {item.description}
                            </p>
                            <Button 
                              className="w-full rounded-xl font-bold gap-2"
                              onClick={() => handleOrderClick(item)}
                            >
                              <Send className="w-4 h-4" />
                              Commander
                            </Button>
                          </CardContent>
                        </Card>
                      )}
                    </motion.div>
                  ))}
                </motion.div>
              </TabsContent>
            ))}
          </AnimatePresence>
        </Tabs>
      </div>

      {restaurant && (
        <QuickOrderModal 
          isOpen={isOrderModalOpen}
          onClose={() => setIsOrderModalOpen(false)}
          item={selectedItem}
          restaurant={restaurant}
        />
      )}
    </section>
  );
}
