import { UtensilsCrossed, Instagram, Facebook, Twitter, MapPin, Phone, Mail } from "lucide-react";
import { useConfig } from "@/ConfigContext";
import { Restaurant } from "@/types";

interface FooterProps {
  restaurant?: Restaurant;
}

export default function Footer({ restaurant: propRestaurant }: FooterProps) {
  const config = useConfig();
  const restaurant = propRestaurant || config?.restaurant;

  if (!restaurant) return null;

  return (
    <footer id="contact" className="bg-foreground text-background py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <UtensilsCrossed className="text-primary-foreground w-6 h-6" />
              </div>
              <span className="font-heading text-2xl font-bold tracking-tight">
                {restaurant.name}
              </span>
            </div>
            <p className="text-background/60 leading-relaxed">
              {restaurant.description}
            </p>
            <div className="flex gap-4">
              {restaurant.config.socials?.instagram && (
                <a href={restaurant.config.socials.instagram} className="w-10 h-10 rounded-full border border-background/20 flex items-center justify-center hover:bg-primary hover:border-primary transition-all">
                  <Instagram className="w-5 h-5" />
                </a>
              )}
              {restaurant.config.socials?.facebook && (
                <a href={restaurant.config.socials.facebook} className="w-10 h-10 rounded-full border border-background/20 flex items-center justify-center hover:bg-primary hover:border-primary transition-all">
                  <Facebook className="w-5 h-5" />
                </a>
              )}
              {restaurant.config.socials?.twitter && (
                <a href={restaurant.config.socials.twitter} className="w-10 h-10 rounded-full border border-background/20 flex items-center justify-center hover:bg-primary hover:border-primary transition-all">
                  <Twitter className="w-5 h-5" />
                </a>
              )}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xl font-heading font-bold mb-6">Liens Rapides</h4>
            <ul className="space-y-4 text-background/60">
              <li><a href="#hero" className="hover:text-primary transition-colors">Accueil</a></li>
              <li><a href="#menu" className="hover:text-primary transition-colors">Notre Carte</a></li>
              <li><a href="#reservation" className="hover:text-primary transition-colors">Réservation</a></li>
              <li><a href="#contact" className="hover:text-primary transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-xl font-heading font-bold mb-6">Contact</h4>
            <ul className="space-y-4 text-background/60">
              <li className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-primary" />
                <span>{restaurant.config.address}</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-primary" />
                <span>{restaurant.config.phone}</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-primary" />
                <span>{restaurant.config.email}</span>
              </li>
            </ul>
          </div>

          {/* Horaires */}
          <div>
            <h4 className="text-xl font-heading font-bold mb-6">Horaires</h4>
            <p className="text-background/60 leading-relaxed">
              {restaurant.config.openingHours || "Consultez-nous pour nos horaires d'ouverture."}
            </p>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-background/10 text-center text-background/40 text-sm">
          <p>&copy; {new Date().getFullYear()} {restaurant.name}. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
}
