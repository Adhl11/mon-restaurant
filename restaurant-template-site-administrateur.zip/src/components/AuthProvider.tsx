import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc, setDoc, query, collection, where, getDocs, updateDoc, onSnapshot } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { UserProfile } from '../types';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  isAuthReady: boolean;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  loading: true,
  isAuthReady: false,
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAuthReady, setIsAuthReady] = useState(false);

  useEffect(() => {
    let unsubProfile: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      
      if (unsubProfile) {
        unsubProfile();
        unsubProfile = null;
      }

      if (firebaseUser) {
        const profileRef = doc(db, 'users', firebaseUser.uid);
        
        unsubProfile = onSnapshot(profileRef, async (profileSnap) => {
          if (profileSnap.exists()) {
            const existingProfile = profileSnap.data() as UserProfile;
            
            if (firebaseUser.email === "adam.duhil@gmail.com" && existingProfile.role !== 'super_admin') {
              await updateDoc(profileRef, { role: 'super_admin' });
              existingProfile.role = 'super_admin';
            }
            setProfile(existingProfile);
            setLoading(false);
            setIsAuthReady(true);
          } else {
            const q = query(collection(db, 'restaurants'), where('ownerEmail', '==', firebaseUser.email));
            const resSnap = await getDocs(q);
            
            let restaurantId: string | undefined = undefined;
            let role: UserProfile['role'] = 'customer';

            if (!resSnap.empty) {
              const resDoc = resSnap.docs[0];
              restaurantId = resDoc.id;
              role = 'restaurant_admin';
              
              await updateDoc(doc(db, 'restaurants', restaurantId), {
                ownerId: firebaseUser.uid
              });
            }

            const isSuperAdmin = firebaseUser.email === "adam.duhil@gmail.com";
            const newProfile: UserProfile = {
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              role: isSuperAdmin ? 'super_admin' : role,
              displayName: firebaseUser.displayName || '',
              restaurantId: restaurantId
            };
            await setDoc(profileRef, newProfile);
          }
        }, (error) => {
          console.error("Profile snapshot error:", error);
          setLoading(false);
          setIsAuthReady(true);
        });
      } else {
        setProfile(null);
        setLoading(false);
        setIsAuthReady(true);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubProfile) unsubProfile();
    };
  }, []);

  const value = useMemo(() => ({
    user,
    profile,
    loading,
    isAuthReady
  }), [user, profile, loading, isAuthReady]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
