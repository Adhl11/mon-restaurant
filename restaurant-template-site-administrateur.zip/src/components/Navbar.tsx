import { motion } from "motion/react";
import { UtensilsCrossed } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useConfig } from "@/ConfigContext";
import { Restaurant } from "@/types";

interface NavbarProps {
  restaurant?: Restaurant;
}

export default function Navbar({ restaurant: propRestaurant }: NavbarProps) {
  const config = useConfig();
  const restaurant = propRestaurant || config?.restaurant;
  
  if (!restaurant) return null;

  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => scrollTo('hero')}>
            {restaurant.config.logo ? (
              <img 
                src={restaurant.config.logo} 
                alt={restaurant.name} 
                className="w-12 h-12 object-contain"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <UtensilsCrossed className="text-primary-foreground w-6 h-6" />
              </div>
            )}
            <span className="font-heading text-2xl font-bold tracking-tight">
              {restaurant.name}
            </span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <button onClick={() => scrollTo('menu')} className="text-sm font-medium hover:text-primary transition-colors">Menu</button>
            <button onClick={() => scrollTo('reservation')} className="text-sm font-medium hover:text-primary transition-colors">Réservation</button>
            <button onClick={() => scrollTo('contact')} className="text-sm font-medium hover:text-primary transition-colors">Contact</button>
            
            <div className="flex items-center gap-4">
              <Button onClick={() => scrollTo('reservation')} className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-6">
                Réserver une table
              </Button>
            </div>
          </div>

          {/* Mobile actions */}
          <div className="md:hidden flex items-center gap-4">
            <Button size="sm" onClick={() => scrollTo('reservation')} className="rounded-full">
              Réserver
            </Button>
          </div>
        </div>
      </div>
    </motion.nav>
  );
}
