export type Category = 'pizza' | 'pasta' | 'antipasti' | 'salade' | 'risotto' | 'specialite' | 'carne' | 'pesce' | 'dolci' | 'all';

export interface MenuItem {
  id: string;
  restaurantId: string;
  name: string;
  description: string;
  price: number;
  category: Category;
  image: string;
  available: boolean;
}

export interface RestaurantConfig {
  primaryColor: string;
  secondaryColor?: string;
  accentColor?: string;
  backgroundColor?: string;
  textColor?: string;
  logo: string;
  heroImage: string;
  address: string;
  phone: string;
  email: string;
  openingHours: string;
  fontFamily?: 'sans' | 'serif' | 'mono';
  layoutStyle?: 'modern' | 'classic' | 'elegant';
  socials: {
    instagram?: string;
    facebook?: string;
    twitter?: string;
  };
}

export interface Restaurant {
  id: string;
  ownerId: string | null;
  ownerEmail?: string;
  slug: string;
  name: string;
  description: string;
  config: RestaurantConfig;
  isOpen: boolean;
  customDomain?: string;
}

export type UserRole = 'super_admin' | 'restaurant_admin' | 'customer';

export interface UserProfile {
  uid: string;
  email: string;
  role: UserRole;
  displayName?: string;
  restaurantId?: string;
}

export interface OrderItem {
  menuItemId: string;
  name: string;
  quantity: number;
  price: number;
}

export type OrderStatus = 'pending' | 'confirmed' | 'preparing' | 'ready' | 'delivered' | 'cancelled';

export interface Order {
  id: string;
  restaurantId: string;
  customerId?: string;
  customerName?: string;
  customerEmail?: string;
  customerPhone?: string;
  items: OrderItem[];
  total: number;
  status: OrderStatus;
  waitingTime?: string;
  createdAt: any; // Firestore Timestamp
}

export interface Reservation {
  id: string;
  restaurantId: string;
  name: string;
  email: string;
  phone?: string;
  date: string;
  time: string;
  guests: number;
  notes?: string;
  status: 'pending' | 'confirmed' | 'cancelled';
  createdAt: any;
}
