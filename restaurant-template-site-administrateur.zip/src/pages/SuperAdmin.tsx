import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../components/AuthProvider';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, onSnapshot, addDoc, doc, updateDoc, query, getDocs, where } from 'firebase/firestore';
import { Restaurant, UserProfile } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Plus, Store, Users, TrendingUp, Download, FileJson, Code, ExternalLink } from 'lucide-react';

export default function SuperAdmin() {
  const { profile } = useAuth();
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [newRestaurant, setNewRestaurant] = useState({ name: '', slug: '', ownerEmail: '', customDomain: '' });
  const [editingDomainId, setEditingDomainId] = useState<string | null>(null);
  const [tempDomain, setTempDomain] = useState('');
  const [loading, setLoading] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const [showExportInfo, setShowExportInfo] = useState(false);

  const profileRole = profile?.role;
  useEffect(() => {
    if (profileRole !== 'super_admin') {
      setLoading(false);
      return;
    }

    const unsubRes = onSnapshot(collection(db, 'restaurants'), (snapshot) => {
      setRestaurants(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Restaurant)));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'restaurants'));

    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      setUsers(snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile)));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'users'));

    setLoading(false);
    return () => {
      unsubRes();
      unsubUsers();
    };
  }, [profileRole]);

  const handleCreateRestaurant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRestaurant.name || !newRestaurant.slug || !newRestaurant.ownerEmail) return;

    try {
      // Check if user already exists
      const q = query(collection(db, 'users'), where('email', '==', newRestaurant.ownerEmail));
      const userSnap = await getDocs(q);
      
      const ownerId = !userSnap.empty ? userSnap.docs[0].id : null;

      // Create restaurant
      const normalizedSlug = newRestaurant.slug.toLowerCase().trim();
      const resRef = await addDoc(collection(db, 'restaurants'), {
        name: newRestaurant.name,
        slug: normalizedSlug,
        ownerId: ownerId,
        ownerEmail: newRestaurant.ownerEmail,
        customDomain: newRestaurant.customDomain || '',
        isOpen: true,
        config: {
          primaryColor: '#000000',
          heroImage: 'https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&q=80',
          address: 'Adresse par défaut',
          phone: '01 02 03 04 05',
          email: newRestaurant.ownerEmail
        }
      });

      // If user exists, update their role immediately
      if (ownerId) {
        await updateDoc(doc(db, 'users', ownerId), {
          role: 'restaurant_admin',
          restaurantId: resRef.id
        });
      }

      setNewRestaurant({ name: '', slug: '', ownerEmail: '', customDomain: '' });
      alert("Restaurant créé avec succès ! " + (!ownerId ? "(L'utilisateur sera lié à sa première connexion)" : ""));
    } catch (error) {
      console.error("Error creating restaurant:", error);
      handleFirestoreError(error, OperationType.WRITE, 'restaurants/users');
    }
  };

  const handleUpdateDomain = async (resId: string) => {
    try {
      await updateDoc(doc(db, 'restaurants', resId), {
        customDomain: tempDomain.trim().toLowerCase()
      });
      setEditingDomainId(null);
    } catch (error) {
      console.error("Error updating domain:", error);
      handleFirestoreError(error, OperationType.UPDATE, `restaurants/${resId}`);
    }
  };

  const handleExportData = async () => {
    setIsExporting(true);
    try {
      const exportData = {
        restaurants: restaurants,
        users: users,
        exportDate: new Date().toISOString(),
        version: "1.0.0"
      };

      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `plateforme_export_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Export error:", error);
      alert("Erreur lors de l'exportation des données.");
    } finally {
      setIsExporting(false);
    }
  };

  if (loading) return <div className="p-8 text-center">Chargement...</div>;

  if (profile?.role !== 'super_admin') {
    return (
      <div className="p-8 text-center">
        <h2 className="text-2xl font-bold text-destructive">Accès Refusé</h2>
        <p>Vous n'avez pas les permissions nécessaires pour accéder à cette page.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        <header>
          <h1 className="text-3xl font-bold">Administration Plateforme</h1>
          <p className="text-muted-foreground">Gérez vos restaurants et clients</p>
        </header>

        <div className="grid md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Restaurants</CardTitle>
              <Store className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{restaurants.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Utilisateurs</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{users.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Croissance</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">+12%</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Nouveau Restaurant</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateRestaurant} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="res-name">Nom du restaurant</Label>
                  <Input 
                    id="res-name" 
                    value={newRestaurant.name} 
                    onChange={e => setNewRestaurant({...newRestaurant, name: e.target.value})}
                    placeholder="Ex: La Belle Table" 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="res-slug">Slug URL</Label>
                  <Input 
                    id="res-slug" 
                    value={newRestaurant.slug} 
                    onChange={e => setNewRestaurant({...newRestaurant, slug: e.target.value})}
                    placeholder="ex: la-belle-table" 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="owner-email">Email du propriétaire</Label>
                  <Input 
                    id="owner-email" 
                    type="email"
                    value={newRestaurant.ownerEmail} 
                    onChange={e => setNewRestaurant({...newRestaurant, ownerEmail: e.target.value})}
                    placeholder="email@exemple.com" 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="res-domain">Domaine personnalisé (Vercel/Custom)</Label>
                  <Input 
                    id="res-domain" 
                    value={newRestaurant.customDomain} 
                    onChange={e => setNewRestaurant({...newRestaurant, customDomain: e.target.value})}
                    placeholder="Ex: www.monrestaurant.fr" 
                  />
                </div>
                <Button type="submit" className="w-full">Créer le restaurant</Button>
              </form>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Liste des Restaurants</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {restaurants.map(res => (
                  <div key={res.id} className="flex flex-col gap-4 p-4 border rounded-lg bg-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-bold text-lg">{res.name}</div>
                        <div className="text-sm text-muted-foreground">/r/{res.slug}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="hidden md:inline-flex">
                          {users.find(u => u.uid === res.ownerId)?.email || res.ownerEmail || 'Inconnu'}
                        </Badge>
                        <div className="flex gap-1">
                          {res.customDomain ? (
                            <a href={`https://${res.customDomain}`} target="_blank" rel="noopener noreferrer">
                              <Button variant="outline" size="sm">Public</Button>
                            </a>
                          ) : (
                            <Link to={`/r/${res.slug}`} target="_blank">
                              <Button variant="outline" size="sm">Public</Button>
                            </Link>
                          )}
                          <Link to={`/dashboard/${res.id}`}>
                            <Button variant="ghost" size="sm">Éditer</Button>
                          </Link>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3 pt-2 border-t">
                      <div className="text-xs font-black text-slate-400 uppercase tracking-widest">Domaine :</div>
                      {editingDomainId === res.id ? (
                        <div className="flex-1 flex gap-2">
                          <Input 
                            value={tempDomain} 
                            onChange={e => setTempDomain(e.target.value)}
                            placeholder="www.exemple.com"
                            className="h-8 text-xs"
                          />
                          <Button size="sm" className="h-8" onClick={() => handleUpdateDomain(res.id)}>OK</Button>
                          <Button size="sm" variant="ghost" className="h-8" onClick={() => setEditingDomainId(null)}>X</Button>
                        </div>
                      ) : (
                        <div className="flex-1 flex items-center justify-between">
                          <span className="text-sm font-mono text-blue-600">
                            {res.customDomain || 'Aucun'}
                          </span>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-7 text-[10px] font-bold"
                            onClick={() => {
                              setEditingDomainId(res.id);
                              setTempDomain(res.customDomain || '');
                            }}
                          >
                            MODIFIER
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Section Maintenance & Export */}
        <div className="pt-8 border-t">
          <h2 className="text-2xl font-bold mb-6">Maintenance & Export</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="border-2 border-blue-100 bg-blue-50/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="w-5 h-5 text-blue-600" />
                  Code Source du Site
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-slate-600">
                  Pour télécharger l'intégralité du code source de la plateforme (pour un déploiement sur Vercel, Netlify, etc.) :
                </p>
                <div className="bg-white p-4 rounded-xl border border-blue-100 text-sm space-y-2">
                  <p className="font-bold text-blue-900 flex items-center gap-2">
                    <span className="w-5 h-5 bg-blue-600 text-white rounded-full flex items-center justify-center text-[10px]">1</span>
                    Allez dans les réglages de AI Studio (icône ⚙️ en haut à droite).
                  </p>
                  <p className="font-bold text-blue-900 flex items-center gap-2">
                    <span className="w-5 h-5 bg-blue-600 text-white rounded-full flex items-center justify-center text-[10px]">2</span>
                    Choisissez "Download ZIP" ou "Export to GitHub".
                  </p>
                </div>
                <Link to="/DEPLOYMENT.md" target="_blank">
                  <Button variant="outline" className="w-full gap-2 border-blue-200 text-blue-700 hover:bg-blue-100">
                    <ExternalLink className="w-4 h-4" />
                    Voir le guide de déploiement
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="border-2 border-slate-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileJson className="w-5 h-5 text-slate-600" />
                  Données de la Plateforme
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-slate-600">
                  Exportez la liste complète des restaurants et des utilisateurs au format JSON pour sauvegarde.
                </p>
                <Button 
                  onClick={handleExportData} 
                  disabled={isExporting}
                  className="w-full gap-2 h-12 rounded-xl font-bold"
                >
                  <Download className="w-4 h-4" />
                  {isExporting ? "Exportation..." : "Télécharger les données (.json)"}
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
