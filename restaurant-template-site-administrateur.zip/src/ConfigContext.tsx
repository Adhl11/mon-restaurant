import { useState, useEffect, createContext, useContext, ReactNode, useMemo } from 'react';
import { Restaurant, MenuItem, RestaurantConfig } from './types';
import { db, handleFirestoreError, OperationType } from './lib/firebase';
import { collection, query, where, getDocs, onSnapshot } from 'firebase/firestore';

interface ConfigContextType {
  restaurant: Restaurant | null;
  menu: MenuItem[];
  isLoading: boolean;
  error: string | null;
  setSlug: (slug: string | null) => void;
}

const ConfigContext = createContext<ConfigContextType | undefined>(undefined);

export function ConfigProvider({ children }: { children: ReactNode }) {
  const [slug, setSlug] = useState<string | null>(null);
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [menu, setMenu] = useState<MenuItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Support for standalone mode (dedicated site for one restaurant)
    const standaloneSlug = import.meta.env.VITE_STANDALONE_RESTAURANT_SLUG;
    const currentHostname = window.location.hostname;
    
    const fetchRestaurant = async () => {
      setIsLoading(true);
      setError(null);

      try {
        let q;
        if (standaloneSlug) {
          q = query(collection(db, 'restaurants'), where('slug', '==', standaloneSlug.toLowerCase().trim()));
        } else if (slug) {
          q = query(collection(db, 'restaurants'), where('slug', '==', slug.toLowerCase().trim()));
        } else if (currentHostname && !currentHostname.includes('webcontainer') && !currentHostname.includes('localhost') && !currentHostname.includes('run.app')) {
          // Try to find by custom domain if not on a dev/platform domain
          q = query(collection(db, 'restaurants'), where('customDomain', '==', currentHostname.toLowerCase().trim()));
        } else {
          setIsLoading(false);
          setRestaurant(null);
          return;
        }

        const unsubRes = onSnapshot(q, (snapshot) => {
          if (snapshot.empty) {
            // If we tried by domain and failed, maybe it's just the platform home
            if (!slug && !standaloneSlug) {
              setRestaurant(null);
              setIsLoading(false);
              return;
            }
            setError('Restaurant non trouvé');
            setRestaurant(null);
          } else {
            const resData = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() } as Restaurant;
            setRestaurant(resData);
            setError(null);
          }
          setIsLoading(false);
        }, (err) => {
          console.error('Error loading restaurant:', err);
          setError('Erreur lors du chargement du restaurant');
          setIsLoading(false);
        });

        return unsubRes;
      } catch (err) {
        console.error('Fetch error:', err);
        setIsLoading(false);
      }
    };

    const unsubPromise = fetchRestaurant();
    return () => {
      unsubPromise.then(unsub => unsub && unsub());
    };
  }, [slug]);

  useEffect(() => {
    if (!restaurant?.id) return;

    const menuQuery = query(collection(db, `restaurants/${restaurant.id}/menu`));
    const unsubMenu = onSnapshot(menuQuery, (menuSnap) => {
      const menuItems = menuSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as MenuItem));
      setMenu(menuItems);
    }, (error) => handleFirestoreError(error, OperationType.LIST, `restaurants/${restaurant.id}/menu`));

    return () => unsubMenu();
  }, [restaurant?.id]);

  const value = useMemo(() => ({
    restaurant,
    menu,
    isLoading,
    error,
    setSlug
  }), [restaurant, menu, isLoading, error]);

  return (
    <ConfigContext.Provider value={value}>
      {children}
    </ConfigContext.Provider>
  );
}

export function useConfig() {
  const context = useContext(ConfigContext);
  if (context === undefined) {
    throw new Error('useConfig must be used within a ConfigProvider');
  }
  return context;
}
