/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Routes, Route, Navigate } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import SuperAdmin from "./pages/SuperAdmin";
import RestaurantView from "./pages/RestaurantView";
import { useAuth } from "./components/AuthProvider";
import { useConfig } from "./ConfigContext";
import { useEffect } from "react";
import { doc, getDocFromServer } from "firebase/firestore";
import { db } from "./lib/firebase";

import { ErrorBoundary } from "./components/ErrorBoundary";

export default function App() {
  const { user, profile, loading } = useAuth();
  const { restaurant } = useConfig();

  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. ");
        }
      }
    }
    testConnection();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const isStandalone = !!import.meta.env.VITE_STANDALONE_RESTAURANT_SLUG || !!restaurant?.customDomain;

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-background selection:bg-primary/30">
        <Routes>
          <Route path="/" element={isStandalone ? <RestaurantView /> : <Home />} />
          <Route 
            path="/login" 
            element={
              user ? (
                profile?.role === 'super_admin' ? <Navigate to="/admin" /> : <Navigate to="/dashboard" />
              ) : (
                <Login />
              )
            } 
          />
          
          <Route 
            path="/dashboard" 
            element={
              profile?.role === 'restaurant_admin' || profile?.role === 'super_admin' 
                ? <Dashboard /> 
                : <Navigate to="/login" />
            } 
          />
          <Route 
            path="/dashboard/:restaurantId" 
            element={
              profile?.role === 'super_admin' 
                ? <Dashboard /> 
                : <Navigate to="/login" />
            } 
          />

          <Route 
            path="/admin" 
            element={
              profile?.role === 'super_admin' 
                ? <SuperAdmin /> 
                : <Navigate to="/login" />
            } 
          />

          <Route path="/r/:slug" element={<RestaurantView />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
    </ErrorBoundary>
  );
}
